package Final_exam;

public class Dates {

	private String string;

	private String string2;
	private String string3;
	private String string4;
	private String string5;
	private String string6;

	public Dates(String string, String string2, String string3, String string4, String string5, String string6) {
		this.string = string;
		this.string2 = string2;
		this.string3 = string3;
		this.string4 = string4;
		this.string5 = string5;
		this.string6 = string6;
	}

	public Dates() {

	}

	public String getString1() {
		return string;
	}

	public String getString2() {
		return string2;
	}

	public String getString3() {
		return string3;
	}

	public String getString4() {
		return string4;
	}

	public String getString5() {
		return string5;
	}

	public String getString6() {
		return string6;
	}
}
